# LogAspect
Tem como responsabilidade logar informando que está chamando o método, antes e depois de ser executado a função.

# NotifyAspect
Notifica todos os Handlers que estão escutando o evento Subject.UpdateEvent