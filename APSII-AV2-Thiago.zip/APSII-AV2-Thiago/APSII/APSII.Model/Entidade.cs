﻿namespace APSII.Model
{
    public abstract class Entidade
    {
        public int Id { get; set; }
        public bool Ativo { get; set; }
    }
}
